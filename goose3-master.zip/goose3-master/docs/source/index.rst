.. _home:

Welcome to goose3's documentation!
===============================================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   code
   quickstart


Indices and tables
===============================================================================

* :ref:`api`
* :ref:`quickstart`
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
